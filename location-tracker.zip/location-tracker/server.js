const express = require('express');
const path = require('path');
const MobileDetect = require('mobile-detect');

const app = express();
const port = 3000;

// Serve static files from the 'pictures' directory
app.use('/pictures', express.static(path.join(__dirname, 'pictures')));

// Middleware to parse JSON
app.use(express.json());

// Serve the main HTML file
app.get('/', (req, res) => {
    console.log('Client visited the page.');
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Handle location data
app.post('/location', (req, res) => {
    console.log('Received location and device information:', req.body);
    if (req.body.latitude && req.body.longitude && req.body.deviceModel) {
        console.log(`Latitude: ${req.body.latitude}, Longitude: ${req.body.longitude}`);

        const md = new MobileDetect(req.body.deviceModel);
        const deviceDetails = {
            os: md.os(),
            phone: md.phone(),
            tablet: md.tablet(),
            userAgent: md.userAgent()
        };

        console.log('Device Details:', deviceDetails);
    } else {
        console.log('No valid location or device information received.');
    }
    res.sendStatus(200);
});

// Handle 404 errors for unknown routes
app.use((req, res) => {
    res.status(404).send('Sorry, page not found!');
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
